# hotspot detection
