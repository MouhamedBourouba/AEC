// Charts logic
